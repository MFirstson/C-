﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManager
{
    public class BookSearchText : ISearchOperator<Book>
    {
        public Book Search(int BookId)
        {
            Book book = new Book();
            StreamReader sr = new StreamReader("LIB.txt");
            int ID = -1;
            while (!sr.EndOfStream && ID != BookId)
            {
                string Line = sr.ReadLine();
                string[] data = Line.Split('|');
                ID = Convert.ToInt32(data[0]);

                book.Id = ID;
                book.Name = data[1];
                book.Author = data[2];
                book.Price = Convert.ToDouble(data[3]);
            }
            sr.Close();
            
            if (BookId != book.Id) Console.WriteLine("ARADIGINIZ KITAP DOSYADA'DA YOK!\n");

            return book;
        }
    }
}
