﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManager
{
    public class BookListText : IListOperator<Book>
    {
        public List<Book> List()
        {
            List<Book> Booklist = new List<Book>();
            StreamReader sr = new StreamReader("LIB.txt");

            while (!sr.EndOfStream)
            {
                string Line = sr.ReadLine();
                string[] data = Line.Split('|');
                
                Book book = new Book();
                
                book.Id = Convert.ToInt32(data[0]);
                book.Name = data[1];
                book.Author = data[2];
                book.Price = Convert.ToDouble(data[3]);
                Booklist.Add(book);
            }
            sr.Close();

            return Booklist;

        }
    }
}
//foreach ile kolleksiyondan class doldurulabilir.