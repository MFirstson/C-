﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManager
{
    public abstract class DataBaseCfg
    {
        public SqlConnection DbConnection()
        {
            SqlConnection Connect;
            string strConn = "Data Source=.;Initial Catalog=master;Integrated Security=True";
            return Connect = new SqlConnection(strConn); ;
        }
    }
}
