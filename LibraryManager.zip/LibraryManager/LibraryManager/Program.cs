﻿using LibraryManager;

//*****************
//METIN BIRINCIOGLU
//*****************

//Sonradan keşke önyüz tasarlasaydım dedim..

Console.WriteLine("Library Manager Console\n");

void PrintData(List<Book> books)
{
    foreach (Book book in books)
        Console.WriteLine(book);
}

string process = " ";
string domain = " ";
int BookIdSearch = 0;

BookAddDb bookAddDb = new BookAddDb();
BookSearchDb bookSearchDb = new BookSearchDb();
BookListDb bookListDb = new BookListDb();
BookAddText bookAddText= new BookAddText();
BookSearchText bookSearchText= new BookSearchText();
BookListText bookListText= new BookListText();

do
{
    Console.WriteLine("Yapmak istediginiz islemi seciniz:");
    Console.WriteLine(" Kitap arama icin 'ARA',");
    Console.WriteLine(" Kitap ekleme icin 'EKLE',");
    Console.WriteLine(" Kitap listeleme icin 'LIST',");
    Console.WriteLine(" Cikis yapmak icin 'CIK' yaziniz..\n");
    process = Console.ReadLine();
    
    if (process == "ARA" || process == "EKLE" || process == "LIST")
    {
        do
        {
            Console.WriteLine("Nereden..\n  Database icin 'DB',  Dosya icin 'TXT'\n  Geri donmek icin 'GERI' yaziniz..\n");
            domain = Console.ReadLine();

            if (domain == "DB")
            {
                if(process == "ARA")
                {
                    Console.WriteLine("  Aramak istediginiz kitabin ID'si:");
                    BookIdSearch = Convert.ToInt32(Console.ReadLine());
                    Manager managerAra = new Manager(bookSearchDb);
                    Console.WriteLine(managerAra.Ara(BookIdSearch));
                    Console.WriteLine();
                }
                else if (process == "EKLE")
                {
                    Book newBook = new Book();
                    Console.WriteLine("  Eklemek istediginiz kitabin adi:");
                    newBook.Name = Console.ReadLine();
                    Console.WriteLine("  Eklemek istediginiz kitabin yazari:");
                    newBook.Author = Console.ReadLine();
                    Console.WriteLine("  Eklemek istediginiz kitabin fiyati:");
                    newBook.Price = Convert.ToDouble(Console.ReadLine());
                    Manager managerEkle = new Manager(bookAddDb);
                    managerEkle.Ekle(newBook);
                    Console.WriteLine("KITAP SQL'E EKLENDI!");

                }
                else if (process == "LIST")
                {
                    Manager managerList = new Manager(bookListDb);
                    Console.WriteLine("Tum kitaplar:");
                    PrintData(managerList.Listele());
                    Console.WriteLine();
                }
            }
            else if (domain == "TXT")
            {
                if (process == "ARA")
                {
                    Console.WriteLine("  Aramak istediginiz kitabin ID'si:");
                    BookIdSearch = Convert.ToInt32(Console.ReadLine());
                    Manager managerAraTxt = new Manager(bookSearchText);
                    Console.WriteLine(managerAraTxt.Ara(BookIdSearch));
                }
                else if (process == "EKLE")
                {
                    Book newBook = new Book();
                    Console.WriteLine("  Eklemek istediginiz kitabin adi:");
                    newBook.Name = Console.ReadLine();
                    Console.WriteLine("  Eklemek istediginiz kitabin yazari:");
                    newBook.Author = Console.ReadLine();
                    Console.WriteLine("  Eklemek istediginiz kitabin fiyati:");
                    newBook.Price = Convert.ToDouble(Console.ReadLine());
                    Manager managerEkleTxt = new Manager(bookAddText);
                    managerEkleTxt.Ekle(newBook);
                    Console.WriteLine("KITAP DOSYAYA EKLENDI!");
                }
                else if (process == "LIST")
                {
                    Manager managerListTxt = new Manager(bookListText);
                    Console.WriteLine("Tum kitaplar:");
                    PrintData(managerListTxt.Listele());
                    Console.WriteLine();
                }
            }
            Console.WriteLine();
        } while (domain != "GERI");
    }
    Console.WriteLine();
} while (process != "CIK");


