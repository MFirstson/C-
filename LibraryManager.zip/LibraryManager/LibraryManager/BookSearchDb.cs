﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManager
{
    public class BookSearchDb : DataBaseCfg, ISearchOperator<Book>
    {
        public Book Search(int BookId)
        {
            Book book = new Book();
            SqlConnection Conn = DbConnection();

            Conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM LIBRARY WHERE BOOK_ID=@Id", Conn);
            cmd.Parameters.AddWithValue("@Id", BookId);

            SqlDataReader dr = cmd.ExecuteReader();

            dr.Read();

            book.Id = -1;
            if (dr.HasRows)
            {
                book.Id = Convert.ToInt32(dr[0]);
                book.Name = dr.GetString(1);
                book.Author = dr.GetString(2);
                book.Price = Convert.ToDouble(dr[3]);

            }
            Conn.Close();

            if (book.Id == -1) Console.WriteLine("ARADIGINIZ KITAP DATABASE'DE YOK!\n");

            return book;
        }
    }
}
