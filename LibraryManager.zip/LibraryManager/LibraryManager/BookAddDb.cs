﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManager
{
    public class BookAddDb : DataBaseCfg, IAddOperator<Book>
    {
        public void Add(Book BookClass)
        {
            SqlConnection Conn = DbConnection();

            Conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO LIBRARY VALUES(@name,@author,@price)", Conn);
            //burası foreach ile doldurulabilir.

            cmd.Parameters.AddWithValue("@name", BookClass.Name);
            cmd.Parameters.AddWithValue("@author", BookClass.Author);
            cmd.Parameters.AddWithValue("@price", BookClass.Price);

            string deneme = BookClass.ToString();

            cmd.ExecuteNonQuery();

            Conn.Close();
        }
    }
}
