﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace LibraryManager
{
    public sealed class Manager
    {
        IAddOperator<Book> _add;
        IListOperator<Book> _list;
        ISearchOperator<Book> _search;
        public Manager()
        {

        }
        public Manager(IAddOperator<Book> add)
        {
            _add = add;
        }
        public Manager(IListOperator<Book> list)
        {
            _list = list;
        }
        public Manager(ISearchOperator<Book> search)
        {
            _search = search;
        }
        
        public void Ekle(Book book)
        {
            _add.Add(book);
        }
        public List<Book> Listele()
        {
            return _list.List();
        }
        public Book Ara(int Id)
        {
            return _search.Search(Id);
        }

    }
}
