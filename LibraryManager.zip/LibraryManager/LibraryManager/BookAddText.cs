﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManager
{
    public class BookAddText : IAddOperator<Book>
    {
        public void Add(Book BookClass)
        {
            #region
            //Find Last Book Id
            string LastBook = " ";
            int NewId = 0;
            string[] Line;
            
            StreamReader sr = new StreamReader("LIB.txt");
            while (!sr.EndOfStream)
            {
                LastBook = sr.ReadLine().ToString();
            }
            sr.Close();

            if(LastBook == " ") NewId = 1;
            else
            {
                Line = LastBook.Split('|');
                NewId = Convert.ToInt32(Line[0]) + 1;
            }
            #endregion

            StreamWriter sw = new StreamWriter("LIB.txt", true);
            sw.WriteLine(NewId.ToString() + "|" + BookClass.Name + "|" + BookClass.Author + "|" + BookClass.Price.ToString());
            sw.Close();
        }
    }
}
