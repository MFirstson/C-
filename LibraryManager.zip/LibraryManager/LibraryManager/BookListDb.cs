﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManager
{
    public class BookListDb : DataBaseCfg, IListOperator<Book>
    {
        public List<Book> List()
        {
            SqlConnection Conn = DbConnection();

            Conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM LIBRARY", Conn);
            //burası foreach ile doldurulabilir.

            SqlDataReader dr = cmd.ExecuteReader();

            List<Book> list = new List<Book>();
            while (dr.Read())
            {
                Book book = new Book();
                book.Id = Convert.ToInt32(dr[0]);
                book.Name = dr.GetString(1);
                book.Author = dr.GetString(2);
                book.Price = Convert.ToDouble(dr[3]);
                list.Add(book);
            }
            Conn.Close();

            return list;
        }
    }
}
